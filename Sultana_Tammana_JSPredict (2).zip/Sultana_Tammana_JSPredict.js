// hello
//Dojo


//hello
//result is 15


//num is 3
// result is 18


//15
//10
//10
//15



//15
//10
//20
//15



//num is 3
//num is 3
//result is 16


//2
//5
//3
//8


//sum is 5
//sum is 8
//result is 13


//sum is 5
//sum is 6
//sum is 8
//result is 19
