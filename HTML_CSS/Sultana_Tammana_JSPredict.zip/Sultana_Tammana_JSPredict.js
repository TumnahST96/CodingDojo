//I was born in 1980

//I was born in 1980

//Summin Numbers!
//num1 is: 10
//num1 is: 20
//30