var childHeight = 5;

function displayIfChildIsAbleToRideTheRollerCoaster (Height){
    if(Height>52){
        console.log("Get on that ride, kiddo!");
    }
    else console.log("Sorry kiddo. Maybe next year.")
}

displayIfChildIsAbleToRideTheRollerCoaster(childHeight);