from flask_app.config.mysqlconnection import MySQLConnection, connectToMySQL

class Show:
    def __init__(self, data):
        self.id = data["id"]

        self.title = data["title"]
        self.network = data["network"]

        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]

    @classmethod
    def get_all():
        query = "SELECT * FROM show"

        return connectToMySQL("tvshows").query_db(query)