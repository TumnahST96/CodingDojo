from flask_app import app
from flask_app.models.allShow import Show
from flask import render_template, session, redirect, request, flash




@app.route("/Dashboard")
def user_login():
    allShow = Show.get_all()
    return render_template("dashboard.html", allShow = allShow)