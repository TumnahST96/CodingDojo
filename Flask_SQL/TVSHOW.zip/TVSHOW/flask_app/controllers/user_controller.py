
from flask_app.models.user import User
from flask_app import app
from flask_bcrypt import Bcrypt
from flask import render_template, session, redirect, request, flash
bcrypt = Bcrypt(app)



@app.route("/")
def index():
    return render_template("index.html")

@app.route("/user_login", methods = ["POST"])
def user_login():
    
    data = {
        "email" : request.form["email"],
        "passcode" : request.form["passcode"]
    }
    
    if not User.validate_login(data):
        return redirect("/")
    return redirect("/Dashboard")


@app.route("/register", methods = ["POST"])
def register_user():
    pw_hash = bcrypt.generate_password_hash(request.form["passcode"])
    # pw_hash1 = bcrypt.generate_password_hash(request.form["confirm_pass"])
    data = {
        'F_name' : request.form["F_name"],
        'L_name' : request.form["L_name"],

        'email' : request.form["email"],
        'passcode' : pw_hash,
        # "confirm_pass" : pw_hash1
    }

    if not User.validate_user(data):
        return redirect("/")

    new_user_id = User.create_user(data)
    return redirect("/Dashboard")